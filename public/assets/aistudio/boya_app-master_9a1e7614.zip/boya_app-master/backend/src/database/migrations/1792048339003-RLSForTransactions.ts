import { MigrationInterface, QueryRunner } from 'typeorm';

export class RLSForTransactions1792048339003 implements MigrationInterface {
  // Fixed name — see ExclusionConstraint for why a runtime-built name breaks.
  name = 'RLSForTransactions1792554473159';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE transactions ENABLE ROW LEVEL SECURITY`);
    await queryRunner.query(`ALTER TABLE transactions FORCE ROW LEVEL SECURITY`);

    // ✅ حذف پالیسی قبلی برای اطمینان از اعمال تغییرات جدید (WITH CHECK)
    await queryRunner.query(`DROP POLICY IF EXISTS transactions_tenant_isolation ON transactions`);

    // ✅ ساخت پالیسی جدید با سینتکس صحیح
    await queryRunner.query(`
      CREATE POLICY transactions_tenant_isolation ON transactions
      USING (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::UUID)
      WITH CHECK (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::UUID);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP POLICY IF EXISTS transactions_tenant_isolation ON transactions`);
    await queryRunner.query(`ALTER TABLE transactions NO FORCE ROW LEVEL SECURITY`);
    await queryRunner.query(`ALTER TABLE transactions DISABLE ROW LEVEL SECURITY`);
  }
}
