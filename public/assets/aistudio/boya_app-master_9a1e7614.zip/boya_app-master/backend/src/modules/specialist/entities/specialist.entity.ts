import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

import { APPROVAL_STATUSES, ApprovalStatus } from '../../../common/approval-status';

@Entity('specialists')
export class Specialist {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string;

  @Column({ name: 'user_id', type: 'uuid' })
  userId!: string;

  @Column({ type: 'text', nullable: true })
  bio!: string | null;

  @Column({ type: 'jsonb', default: () => `'[]'::jsonb` })
  skills!: string[];

  @Column({ name: 'commission_rate', type: 'decimal', precision: 5, scale: 2, default: 50 })
  commissionRate!: string;

  @Column({ name: 'is_active', type: 'boolean', default: true })
  isActive!: boolean;

  /**
   * On-site services (ADR-011): this specialist travels to the customer. Set by
   * the specialist/owner; a service can only be booked on-site when *both* this
   * and `services.is_mobile_available` are true.
   */
  @Column({ name: 'offers_mobile_service', type: 'boolean', default: false })
  offersMobileService!: boolean;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' })
  createdAt!: Date;

  // --- Approval workflow (migration 1730000000018) ---
  // Adding or editing a specialist is free per the approval policy, so a new
  // row lands here as 'draft' and its creator decides whether it needs review.
  // These four columns exist only because the migration adds them to the table.
  // See Tenant.status for why the enum is declared with `enumName`.
  @Column({
    name: 'status',
    type: 'enum',
    enumName: 'approval_status',
    enum: [...APPROVAL_STATUSES],
    default: 'draft',
  })
  status!: ApprovalStatus;

  @Column({ name: 'rejection_reason', type: 'text', nullable: true })
  rejectionReason!: string | null;

  @Column({ name: 'approved_at', type: 'timestamptz', nullable: true })
  approvedAt!: Date | null;

  @Column({ name: 'approved_by', type: 'uuid', nullable: true })
  approvedBy!: string | null;

  /**
   * Onboarding flag (migration 1730000000033): true once the specialist (or
   * the owner editing them) has filled in bio/skills/hours. `false` on a
   * freshly invited row is what routes the specialist into
   * `SpecialistProfileSetupScreen`.
   */
  @Column({ name: 'profile_completed', type: 'boolean', default: false })
  profileCompleted!: boolean;

  /**
   * The specialist's *stated* hours, kept for the profile. Not the schedule
   * bookings are checked against — that is still `tenants.working_hours`.
   */
  @Column({ name: 'working_hours', type: 'jsonb', nullable: true })
  workingHours!: Record<string, unknown> | null;
}
